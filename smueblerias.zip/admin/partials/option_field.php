<input type="text" name="smuebleria_config_options" value="<?php get_option('smuebleria_config_options', 'hola'); ?>" />
