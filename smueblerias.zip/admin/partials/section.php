<p><?php _e('Sección de configuración de sMueblerias', 'smuebleria_plugin'); ?></p>
